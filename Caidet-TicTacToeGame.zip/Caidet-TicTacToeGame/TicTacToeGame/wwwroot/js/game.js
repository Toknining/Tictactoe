﻿let board = ["", "", "", "", "", "", "", "", ""];
let currentPlayer = "X";
let gameOver = false;
let aiPlayer = "O"; // Default AI is O
let humanPlayer = "X"; // Default Human is X
let gameMode = "player"; // "cpu" or "player"

// Handle player selection
function selectPlayer(player) {
    humanPlayer = player;
    aiPlayer = player === "X" ? "O" : "X";
    document.querySelectorAll(".choice").forEach(choice => choice.classList.remove("active"));
    document.querySelector(`.choice:nth-child(${player === "X" ? 1 : 2})`).classList.add("active");

    // If AI is 'X', let AI go first
    if (gameMode === "cpu" && aiPlayer === "X") {
        setTimeout(aiMove, 500);
    }
}

// Start game mode
function startGame(mode) {
    gameMode = mode;
    document.querySelector(".selection-container").style.display = "none";
    document.getElementById("gameBoard").style.display = "block";
    resetBoard();

    // If AI is 'X', make its first move
    if (gameMode === "cpu" && aiPlayer === "X") {
        setTimeout(aiMove, 500);
    }
}

// Handle player moves
function makeMove(index) {
    if (!board[index] && !gameOver) {
        board[index] = currentPlayer;
        document.getElementById(`cell-${index}`).innerText = currentPlayer;
        document.getElementById(`cell-${index}`).classList.add(currentPlayer.toLowerCase());

        let winner = checkWinner();
        if (winner) {
            gameOver = true;
            updateScore(winner);
            document.getElementById("turnDisplay").innerText = winner === "Tie" ? "It's a Tie!" : `${winner} Wins!`;
            return;
        }

        switchTurn();

        // If playing vs CPU and it's AI's turn, AI should make a move
        if (gameMode === "cpu" && currentPlayer === aiPlayer && !gameOver) {
            setTimeout(aiMove, 500);
        }
    }
}

// AI move logic (Minimax)
function aiMove() {
    let bestMove = findBestMove();
    if (bestMove !== null) {
        makeMove(bestMove);
    }
}

// Minimax Algorithm for AI Decision Making
function findBestMove() {
    let bestScore = -Infinity;
    let move = null;

    for (let i = 0; i < board.length; i++) {
        if (board[i] === "") {
            board[i] = aiPlayer;
            let score = minimax(board, 0, false);
            board[i] = "";
            if (score > bestScore) {
                bestScore = score;
                move = i;
            }
        }
    }
    return move;
}

// Minimax Algorithm
function minimax(board, depth, isMaximizing) {
    let winner = checkWinner();
    if (winner) {
        if (winner === aiPlayer) return 10 - depth;
        if (winner === humanPlayer) return depth - 10;
        return 0;
    }

    if (isMaximizing) {
        let bestScore = -Infinity;
        for (let i = 0; i < board.length; i++) {
            if (board[i] === "") {
                board[i] = aiPlayer;
                let score = minimax(board, depth + 1, false);
                board[i] = "";
                bestScore = Math.max(score, bestScore);
            }
        }
        return bestScore;
    } else {
        let bestScore = Infinity;
        for (let i = 0; i < board.length; i++) {
            if (board[i] === "") {
                board[i] = humanPlayer;
                let score = minimax(board, depth + 1, true);
                board[i] = "";
                bestScore = Math.min(score, bestScore);
            }
        }
        return bestScore;
    }
}

// Check for winner or tie
function checkWinner() {
    const winPatterns = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
        [0, 4, 8], [2, 4, 6]             // Diagonals
    ];

    for (let pattern of winPatterns) {
        const [a, b, c] = pattern;
        if (board[a] && board[a] === board[b] && board[a] === board[c]) {
            return board[a];
        }
    }

    return board.includes("") ? null : "Tie";
}

// Update scoreboard
function updateScore(winner) {
    if (winner === "X") document.getElementById("xScore").innerText++;
    if (winner === "O") document.getElementById("oScore").innerText++;
    if (winner === "Tie") document.getElementById("tieScore").innerText++;
}

// Switch turns
function switchTurn() {
    currentPlayer = currentPlayer === "X" ? "O" : "X";
    document.getElementById("turnDisplay").innerText = `${currentPlayer} TURN`;
}

// Restart game
function restartGame() {
    board = ["", "", "", "", "", "", "", "", ""];
    gameOver = false;
    currentPlayer = "X";
    document.getElementById("turnDisplay").innerText = "X TURN";
    document.querySelectorAll(".cell").forEach(cell => {
        cell.innerText = "";
        cell.classList.remove("x", "o");
    });

    // If AI is 'X', make its first move
    if (gameMode === "cpu" && aiPlayer === "X") {
        setTimeout(aiMove, 500);
    }
}
